
import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Plus, Trophy, BarChart3, Users, Award, Trash2, AlertCircle, Zap, Globe, Share2, Check, CloudSync, CloudOff, RefreshCw, Link as LinkIcon, WifiOff } from 'lucide-react';
import { Student, RankedStudent } from './types';
import StudentForm from './components/StudentForm';
import RankTable from './components/RankTable';
import StatsOverview from './components/StatsOverview';
import PerformanceChart from './components/PerformanceChart';
import VTUImporter from './components/VTUImporter';

const MAX_STUDENTS = 100;
const STORAGE_KEY = 'vtu_leaderboard_local';
// npoint.io is more reliable for returning IDs in the response body vs headers
const CLOUD_API = 'https://api.npoint.io';

const App: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [isSelfRegistered, setIsSelfRegistered] = useState(false);
  const [activeTab, setActiveTab] = useState<'manual' | 'vtu'>('manual');
  const [copied, setCopied] = useState(false);
  const [cloudId, setCloudId] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'error' | 'local'>('local');

  // --- CLOUD SYNC LOGIC ---

  const saveToCloud = useCallback(async (data: Student[], id: string) => {
    setIsSyncing(true);
    setSyncStatus('syncing');
    try {
      const response = await fetch(`${CLOUD_API}/${id}`, {
        method: 'POST', // npoint uses POST to overwrite existing bins if not using account
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(data),
        mode: 'cors'
      });
      if (!response.ok) throw new Error("Sync failed");
      setSyncStatus('synced');
    } catch (err) {
      console.error("Cloud Save Failed:", err);
      setSyncStatus('error');
    } finally {
      setIsSyncing(false);
    }
  }, []);

  const createCloudBin = async (initialData: Student[]) => {
    setIsSyncing(true);
    setSyncStatus('syncing');
    try {
      const response = await fetch(CLOUD_API, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(initialData),
        mode: 'cors'
      });
      
      const result = await response.json();
      if (result.id) {
        const id = result.id;
        setCloudId(id);
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.set('board', id);
        window.history.replaceState(null, '', newUrl.toString());
        setSyncStatus('synced');
        return id;
      }
    } catch (err) {
      console.error("Failed to create cloud bin", err);
      setSyncStatus('error');
    } finally {
      setIsSyncing(false);
    }
    return null;
  };

  const fetchFromCloud = useCallback(async (id: string) => {
    setIsSyncing(true);
    setSyncStatus('syncing');
    try {
      const response = await fetch(`${CLOUD_API}/${id}`, {
        mode: 'cors',
        headers: { 'Accept': 'application/json' }
      });
      if (!response.ok) throw new Error("Leaderboard not found or expired");
      const data = await response.json();
      if (Array.isArray(data)) {
        setStudents(data);
        setIsSelfRegistered(data.some(s => s.isSelf));
        setSyncStatus('synced');
      }
    } catch (err) {
      console.error("Cloud Fetch Failed:", err);
      setSyncStatus('error');
      // On failure, try to load from local storage as backup
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        setStudents(parsed);
      }
    } finally {
      setIsSyncing(false);
    }
  }, []);

  // --- INITIALIZATION ---

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const boardId = params.get('board');

    if (boardId) {
      setCloudId(boardId);
      fetchFromCloud(boardId);
    } else {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        setStudents(parsed);
        setIsSelfRegistered(parsed.some((s: Student) => s.isSelf));
      }
    }
  }, [fetchFromCloud]);

  // --- DATA MUTATION ---

  const addStudent = async (newStudent: Student) => {
    if (students.length >= MAX_STUDENTS) {
      alert(`Limit reached! You can track up to ${MAX_STUDENTS} students.`);
      return;
    }
    
    if (students.some(s => s.usn.toLowerCase() === newStudent.usn.toLowerCase())) {
      alert("This USN is already in the leaderboard!");
      return;
    }

    const updatedStudents = [...students, newStudent];
    setStudents(updatedStudents);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedStudents));

    if (newStudent.isSelf) setIsSelfRegistered(true);

    // Immediate Sync
    if (cloudId) {
      await saveToCloud(updatedStudents, cloudId);
    } else {
      await createCloudBin(updatedStudents);
    }
  };

  const removeStudent = async (id: string) => {
    const updated = students.filter(s => s.id !== id);
    setStudents(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    
    const wasSelf = students.find(s => s.id === id)?.isSelf;
    if (wasSelf) setIsSelfRegistered(false);

    if (cloudId) await saveToCloud(updated, cloudId);
  };

  const shareLeaderboard = () => {
    if (!cloudId) {
      alert("Creating a cloud session first... Please wait a moment.");
      createCloudBin(students);
      return;
    }
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const rankedStudents: RankedStudent[] = useMemo(() => {
    return [...students]
      .sort((a, b) => b.marks - a.marks)
      .map((student, index) => ({
        ...student,
        rank: index + 1
      }));
  }, [students]);

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Trophy className="text-white w-6 h-6" />
              </div>
              <div className="flex flex-col">
                <h1 className="text-lg font-bold text-slate-900 leading-none">
                  RankMaster <span className="text-indigo-600">Pro</span>
                </h1>
                <div className="flex items-center gap-1.5 mt-1">
                  {syncStatus === 'synced' ? (
                    <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold uppercase tracking-wider">
                      <CloudSync className="w-3 h-3" /> Live Database
                    </span>
                  ) : syncStatus === 'syncing' ? (
                    <span className="flex items-center gap-1 text-[10px] text-indigo-500 font-bold uppercase tracking-wider">
                      <RefreshCw className="w-3 h-3 animate-spin" /> Saving...
                    </span>
                  ) : syncStatus === 'error' ? (
                    <button 
                      onClick={() => cloudId ? saveToCloud(students, cloudId) : createCloudBin(students)}
                      className="flex items-center gap-1 text-[10px] text-red-500 font-bold uppercase tracking-wider hover:underline"
                    >
                      <WifiOff className="w-3 h-3" /> Sync Error - Retry?
                    </button>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      <CloudOff className="w-3 h-3" /> Offline Mode
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={shareLeaderboard}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${copied ? 'bg-emerald-100 text-emerald-700' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md shadow-indigo-100'}`}
              >
                {copied ? <Check className="w-4 h-4" /> : <LinkIcon className="w-4 h-4" />}
                {copied ? 'Copied Link!' : 'Copy Share Link'}
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!isSelfRegistered && students.length === 0 ? (
          <div className="max-w-xl mx-auto">
            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase mb-4">
                <Globe className="w-3 h-3" /> Secure Shared Environment
              </div>
              <h2 className="text-3xl font-extrabold text-slate-900 mb-2">Class Leaderboard</h2>
              <p className="text-slate-600">Join the ranking by entering your academic details.</p>
            </div>
            <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-8">
               <StudentForm onAdd={addStudent} isInitialSelfEntry={true} disabled={isSyncing} />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="flex border-b border-slate-100">
                  <button 
                    onClick={() => setActiveTab('manual')}
                    className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors ${activeTab === 'manual' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30' : 'text-slate-400 hover:bg-slate-50'}`}
                  >
                    <Plus className="w-4 h-4" />
                    Manual
                  </button>
                  <button 
                    onClick={() => setActiveTab('vtu')}
                    className={`flex-1 py-4 text-sm font-bold flex items-center justify-center gap-2 transition-colors ${activeTab === 'vtu' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30' : 'text-slate-400 hover:bg-slate-50'}`}
                  >
                    <Zap className="w-4 h-4" />
                    VTU Import
                  </button>
                </div>

                <div className="p-6">
                  {activeTab === 'manual' ? (
                    <StudentForm onAdd={addStudent} isInitialSelfEntry={false} disabled={isSyncing} />
                  ) : (
                    <VTUImporter onAdd={addStudent} />
                  )}
                  
                  {isSyncing && (
                    <div className="mt-4 flex items-center justify-center gap-2 text-xs text-indigo-500 font-bold animate-pulse">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      Updating Cloud Database...
                    </div>
                  )}
                </div>
              </div>

              <StatsOverview rankedStudents={rankedStudents} />
              
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-center gap-2 mb-4">
                  <BarChart3 className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-bold text-slate-800 text-sm">Visual Distribution</h3>
                </div>
                <PerformanceChart students={rankedStudents} />
              </div>
            </div>

            <div className="lg:col-span-8 space-y-6">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Award className="w-8 h-8 text-amber-500" />
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Live Rankings</h2>
                    <p className="text-sm text-slate-500">Global Class View ({students.length} Students)</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => cloudId && fetchFromCloud(cloudId)}
                    disabled={isSyncing}
                    className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 text-slate-600 transition-all text-xs font-bold disabled:opacity-50"
                  >
                    <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                    Refresh
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <RankTable 
                  students={rankedStudents} 
                  onRemove={removeStudent} 
                />
              </div>

              {rankedStudents.length === 0 && (
                <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
                  <Users className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500 font-medium">Waiting for first entry...</p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
