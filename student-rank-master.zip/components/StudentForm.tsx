
import React, { useState, useMemo } from 'react';
import { User, Hash, Star, UserCheck, Calculator } from 'lucide-react';
import { Student } from '../types';

interface StudentFormProps {
  onAdd: (student: Student) => void;
  isInitialSelfEntry: boolean;
  disabled?: boolean;
}

const StudentForm: React.FC<StudentFormProps> = ({ onAdd, isInitialSelfEntry, disabled }) => {
  const [name, setName] = useState('');
  const [usn, setUsn] = useState('');
  // Initialize with 7 subjects as per typical VTU semester (out of 700)
  const [subjects, setSubjects] = useState<string[]>(['', '', '', '', '', '', '']);

  const totalCalculated = useMemo(() => {
    return subjects.reduce((acc, val) => acc + (Number(val) || 0), 0);
  }, [subjects]);

  const handleSubjectChange = (index: number, value: string) => {
    // Allow empty string for clearing
    if (value === '') {
      const newSubjects = [...subjects];
      newSubjects[index] = '';
      setSubjects(newSubjects);
      return;
    }

    // Limit to 3 digits (up to 999) as requested
    if (value.length > 3) return;

    const val = Number(value);
    if (isNaN(val) || val < 0) return;

    const newSubjects = [...subjects];
    newSubjects[index] = value;
    setSubjects(newSubjects);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (disabled || !name || !usn) return;

    onAdd({
      id: crypto.randomUUID(),
      name,
      usn,
      marks: totalCalculated,
      isSelf: isInitialSelfEntry
    });

    setName('');
    setUsn('');
    setSubjects(['', '', '', '', '', '', '']);
  };

  return (
    <form onSubmit={handleSubmit} className={`space-y-4 ${disabled ? 'opacity-50 pointer-events-none' : ''}`}>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <label className="block text-sm font-semibold text-slate-700 mb-1">
            {isInitialSelfEntry ? "Your Full Name" : "Student Name"}
          </label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              required
              disabled={disabled}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-black"
              placeholder="John Doe"
            />
          </div>
        </div>

        <div className="sm:col-span-2">
          <label className="block text-sm font-semibold text-slate-700 mb-1">
            USN / Roll Number
          </label>
          <div className="relative">
            <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              required
              disabled={disabled}
              value={usn}
              onChange={(e) => setUsn(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-black"
              placeholder="e.g. 1MS21CS101"
            />
          </div>
        </div>
      </div>

      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
            <Calculator className="w-3 h-3" />
            Subject Wise Marks (Max 3 Digits)
          </label>
          <div className="flex flex-col items-end">
             <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg">
              Total: {totalCalculated}
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-2">
          {subjects.map((mark, idx) => (
            <div key={idx} className="space-y-1">
              <input
                type="number"
                placeholder={`Sub ${idx + 1}`}
                value={mark}
                max="999"
                min="0"
                onChange={(e) => handleSubjectChange(idx, e.target.value)}
                className="w-full text-center py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold text-black focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              />
            </div>
          ))}
          <div className="flex items-center justify-center bg-indigo-600 text-white rounded-lg text-[9px] font-bold uppercase leading-tight text-center px-1">
            Auto Calculating
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={disabled || totalCalculated === 0}
        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 group disabled:bg-slate-300 disabled:shadow-none"
      >
        {isInitialSelfEntry ? (
          <>
            <UserCheck className="w-5 h-5" />
            Register Profile
          </>
        ) : (
          <>
            <Star className="w-5 h-5 group-hover:rotate-12 transition-transform" />
            Add to Class Rank
          </>
        )}
      </button>
    </form>
  );
};

export default StudentForm;
