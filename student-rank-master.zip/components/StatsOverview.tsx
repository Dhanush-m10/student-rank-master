
import React from 'react';
import { RankedStudent } from '../types';
import { TrendingUp, Users, Target } from 'lucide-react';

interface StatsOverviewProps {
  rankedStudents: RankedStudent[];
}

const StatsOverview: React.FC<StatsOverviewProps> = ({ rankedStudents }) => {
  const avgMarks = rankedStudents.length > 0 
    ? Math.round(rankedStudents.reduce((acc, s) => acc + s.marks, 0) / rankedStudents.length)
    : 0;
  
  const topScore = rankedStudents.length > 0 ? rankedStudents[0].marks : 0;

  return (
    <div className="grid grid-cols-1 gap-4">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex items-center gap-4">
        <div className="bg-emerald-50 p-3 rounded-xl text-emerald-600">
          <Target className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Class Top Score</p>
          <p className="text-2xl font-bold text-slate-900">{topScore}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex items-center gap-4">
        <div className="bg-blue-50 p-3 rounded-xl text-blue-600">
          <TrendingUp className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Average Marks</p>
          <p className="text-2xl font-bold text-slate-900">{avgMarks}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 flex items-center gap-4">
        <div className="bg-indigo-50 p-3 rounded-xl text-indigo-600">
          <Users className="w-6 h-6" />
        </div>
        <div>
          <p className="text-sm text-slate-500 font-medium">Total Entries</p>
          <p className="text-2xl font-bold text-slate-900">{rankedStudents.length}</p>
        </div>
      </div>
    </div>
  );
};

export default StatsOverview;
