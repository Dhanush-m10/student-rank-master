
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Zap, Loader2, CheckCircle2, AlertCircle, ExternalLink, ShieldCheck } from 'lucide-react';
import { Student } from '../types';

interface VTUImporterProps {
  onAdd: (student: Student) => void;
}

const VTUImporter: React.FC<VTUImporterProps> = ({ onAdd }) => {
  const [text, setText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleImport = async () => {
    if (!text.trim()) return;

    setIsProcessing(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Extract student data from this VTU result text. 
        CRITICAL INSTRUCTIONS:
        1. Identify the Student Name and USN.
        2. Look at the marks table. For each subject, find the total marks obtained.
        3. Sum up all these subject marks to get a final total out of 700.
        4. Return ONLY a JSON object.
        
        Text: ${text}`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "Student's full name" },
              usn: { type: Type.STRING, description: "University Seat Number" },
              totalMarks: { type: Type.NUMBER, description: "Sum of all subject marks (Calculated total)" }
            },
            required: ["name", "usn", "totalMarks"]
          }
        }
      });

      const result = JSON.parse(response.text || '{}');
      
      if (result.name && result.usn && result.totalMarks !== undefined) {
        onAdd({
          id: crypto.randomUUID(),
          name: result.name,
          usn: result.usn,
          marks: result.totalMarks,
          isSelf: false
        });
        setText('');
        alert(`Calculated Total: ${result.totalMarks}/700 for ${result.name}`);
      } else {
        throw new Error("Could not calculate total marks. Make sure to copy the whole result page including the marks table.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to process result. Ensure you copied the full page content.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100">
        <h4 className="text-xs font-bold text-indigo-700 uppercase tracking-wider mb-2 flex items-center gap-2">
          <ShieldCheck className="w-3 h-3" />
          VTU Portal Integration
        </h4>
        <div className="space-y-3">
          <ol className="text-[11px] text-indigo-800 space-y-2 list-decimal ml-4">
            <li>Click <strong>Open VTU Portal</strong> below</li>
            <li>Solve the <strong>Captcha</strong> and view results on VTU site</li>
            <li>Press <strong>Ctrl+A</strong> then <strong>Ctrl+C</strong> on that result page</li>
            <li>Paste the text here to auto-calculate the total</li>
          </ol>
          <a 
            href="https://results.vtu.ac.in/D25J26Ecbcs/index.php" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-full py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-colors"
          >
            <ExternalLink className="w-3 h-3" />
            1. Open VTU Portal (New Tab)
          </a>
        </div>
      </div>

      <div className="relative">
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          2. Paste Copied Results
        </label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste the whole result page text here..."
          className="w-full h-24 p-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-[12px] font-mono text-black shadow-inner"
          disabled={isProcessing}
        />
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-100 rounded-lg text-red-600 text-[10px] flex gap-2">
          <AlertCircle className="w-3 h-3 flex-shrink-0" />
          {error}
        </div>
      )}

      <button
        onClick={handleImport}
        disabled={isProcessing || !text.trim()}
        className="w-full bg-slate-900 hover:bg-black text-white font-bold py-3 rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group"
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            Calculating Total...
          </>
        ) : (
          <>
            <Zap className="w-5 h-5 text-amber-400 group-hover:scale-110 transition-transform" />
            3. Smart Calculate & Rank
          </>
        )}
      </button>
    </div>
  );
};

export default VTUImporter;
