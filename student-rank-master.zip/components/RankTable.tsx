
import React from 'react';
import { RankedStudent } from '../types';
import { Medal, Trash2, UserCircle } from 'lucide-react';

interface RankTableProps {
  students: RankedStudent[];
  onRemove: (id: string) => void;
}

const RankTable: React.FC<RankTableProps> = ({ students, onRemove }) => {
  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1: return { bg: 'bg-amber-50', text: 'text-amber-700', icon: 'text-amber-500', label: 'Gold' };
      case 2: return { bg: 'bg-slate-50', text: 'text-slate-700', icon: 'text-slate-400', label: 'Silver' };
      case 3: return { bg: 'bg-orange-50', text: 'text-orange-700', icon: 'text-orange-500', label: 'Bronze' };
      default: return { bg: 'bg-transparent', text: 'text-slate-500', icon: 'text-slate-300', label: '' };
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead className="bg-slate-50 border-b border-slate-200">
          <tr>
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Rank</th>
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Student Details</th>
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Marks</th>
            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {students.map((student) => {
            const style = getRankStyle(student.rank);
            return (
              <tr 
                key={student.id} 
                className={`group hover:bg-slate-50 transition-colors ${student.isSelf ? 'bg-indigo-50/50' : ''}`}
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-3">
                    <span className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${style.bg} ${style.text}`}>
                      {student.rank <= 3 ? <Medal className={`w-5 h-5 ${style.icon}`} /> : student.rank}
                    </span>
                    {student.rank <= 3 && (
                      <span className={`text-[10px] font-bold uppercase tracking-widest ${style.text} hidden sm:block`}>
                        {style.label}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                      <UserCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-black">{student.name}</span>
                        {student.isSelf && (
                          <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 text-[10px] font-bold uppercase">You</span>
                        )}
                      </div>
                      <div className="text-sm text-slate-500">{student.usn}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <span className="text-lg font-bold text-black">{student.marks}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right">
                  <button
                    onClick={() => onRemove(student.id)}
                    className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default RankTable;
